#include <iostream>
using namespace std;

int main(void) {
    std::cout << "Hello, World" << std::endl;
    return 0;
}
