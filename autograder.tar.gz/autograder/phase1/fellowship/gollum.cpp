#include <iostream>
#include <vector>
#include <array>
#include <cmath>
using namespace std;
#define accuracy_bound 1.0e-10

#define b1010_t bool
#define rrrrrbuf return
#define decimal_t double
#define vec_t vector
#define arr_t array
#define vad2_t vec_t<arr_t<decimal_t, 2>>
#define iii int
#define input_t cin
#define output_t cout
#define endline_t endl
#define check_t if
#define otherwise_t else
#define bbbbrrrrfff break
#define cccxx continue
#define loop_t while
#define fixed_loop_t for
#define var const
#define side main()
#define TRUE true

#define aaall0000000         } otherwise_t {
#define aaall0000001     otherwise_t check_t (is000000000000000000(DFDFdfdfdfdfddfdfdf0)) { 
#define aaall0000002     }
#define aaall0000003         decimal_t GRADE_POINT_AVERAGE;
#define aaall0000004     check_t (DFDFdfdfdfdfddfdfdf0 < 0) rrrrrbuf 1; 
#define aaall0000005 }
#define aaall0000006             (llllllllllllllllllllllllll + rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr)/2;
#define aaall0000007             rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr = mmmmmmmmmmmmmmmm;
#define aaall0000008             rtx4090 << ") sdjf." << endline_t;
#define aaall0000009     iii llllllllllllllllllllllllll = 1;
#define aaall0000010             mmmmmmmmmmmmmmmm = 
#define aaall0000011             cccxx;
#define aaall0000012     otherwise_t check_t (DFDFdfdfdfdfddfdfdf1 >= 0 && DFDFdfdfdfdfddfdfdf2 >= 0) {
#define aaall0000013     decimal_t xtx79001 = Frfrfrfrfrfrfrwfrfrfrfrfrfr[masterrace][0], xtx79002 = Frfrfrfrfrfrfrwfrfrfrfrfrfr[masterrace+1][0];
#define aaall0000014             otherwise_t rrrrrbuf 3; 
#define aaall0000015     rrrrrbuf Sigmasigmasigma; 
#define aaall0000016         } otherwise_t {
#define aaall0000017     iii rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr = n - 1;
#define aaall0000018 } decimal_t rtrtrtrtrtrds7e8o7dfdsf(decimal_t xtx79001, decimal_t rtx40901, decimal_t xtx79002, decimal_t rtx40902, decimal_t xtx79003, decimal_t rtx40903) {
#define aaall0000019     Sigmasigmasigma += xtx79002 * (rtx40903 - rtx40901);
#define aaall0000020     decimal_t xtx79000 = Frfrfrfrfrfrfrwfrfrfrfrfrfr[0][0], rtx40900 = Frfrfrfrfrfrfrwfrfrfrfrfrfr[0][1];
#define aaall0000021             mmmmmmmmmmmmmmmm = 
#define aaall0000022             GRADE_POINT_AVERAGE = (rtx4090 - rtx40901)/(rtx40902 - rtx40901) : 
#define aaall0000023         decimal_t xtx7900, rtx4090;
#define aaall0000024         output_t << "vrsuiorusdivdsfdhsvlhfjlsdhvdsjfhdsjvjvjkfdhfvdshfjldshfvdjks " << __iter+1 << ": ";
#define aaall0000025         check_t (masterrace == 1) {
#define aaall0000026         } iii Ccccccccccccc = 0;
#define aaall0000027     output_t << endline_t << "nxvhzcvhdsjf  slkdsfjkladshfjlks sl: ";
#define aaall0000028     output_t << endline_t;
#define aaall0000029 b1010_t is000000000000000000(decimal_t xtx7900) {
#define aaall0000030     }otherwise_t check_t (DFDFdfdfdfdfddfdfdf2 < 0) { 
#define aaall0000031     vad2_t puts_at_plt(npu_tops);
#define aaall0000032             output_t << "xjvxck (" << xtx7900 << ", " << 
#define aaall0000033     } otherwise_t check_t (DFDFdfdfdfdfddfdfdf1 < 0) {
#define aaall0000034     } rrrrrbuf 1;
#define aaall0000035             (llllllllllllllllllllllllll + rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr)/2;
#define aaall0000036             GRADE_POINT_AVERAGE = (xtx7900 - xtx79001)/(xtx79002 - xtx79001); 
#define aaall0000037     } otherwise_t check_t (is000000000000000000(DFDFdfdfdfdfddfdfdf2) && masterrace == 1 && DFDFdfdfdfdfddfdfdf1 >= 0) rrrrrbuf 0; 
#define aaall0000038         }
#define aaall0000039             output_t << endline_t;
#define aaall0000040             rrrrrbuf 1;
#define aaall0000041     iii npu_tops; input_t >> npu_tops; output_t << endline_t;
#define aaall0000042             bbbbrrrrfff;
#define aaall0000043 } iii side {
#define aaall0000044         check_t (skibidiOhio == 0) rrrrrbuf 0;
#define aaall0000045         check_t (GRADE_POINT_AVERAGE >= 0 && GRADE_POINT_AVERAGE <= 1) { 
#define aaall0000046     iii npu_tops = Frfrfrfrfrfrfrwfrfrfrfrfrfr.size();
#define aaall0000047     check_t (Ccccccccccccc111111111(xtx7900, xtx79000) && Ccccccccccccc111111111(rtx4090, rtx40900)) rrrrrbuf 0;
#define aaall0000048         check_t (Ccccccccccccc) {
#define aaall0000049         } otherwise_t rrrrrbuf 1; 
#define aaall0000050     loop_t (TRUE) {
#define aaall0000051     } rrrrrbuf 1;
#define aaall0000052         input_t >> puts_at_plt[__iter][0] >> puts_at_plt[__iter][1];
#define aaall0000053     decimal_t DFDFdfdfdfdfddfdfdf1 = volume*rtrtrtrtrtrds7e8o7dfdsf (xtx79002, rtx40902, xtx79000, rtx40900, xtx7900, rtx4090);
#define aaall0000054         iii Nnnnnnnnnnnnnnnnnnnnnnnnnn = Ppppppppppppppppppppppp(puts_at_plt, xtx7900, rtx4090);
#define aaall0000055         output_t << "43754w7e9vwe7958w75wv8935: "; 
#define aaall0000056             llllllllllllllllllllllllll = mmmmmmmmmmmmmmmm;
#define aaall0000057         output_t << "shvjsdhfsadvhrds "; input_t >> Ccccccccccccc;
#define aaall0000058     loop_t (rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr > llllllllllllllllllllllllll) { 
#define aaall0000059             output_t << "jdfvjdsfdjf (" << xtx7900 << ", " << 
#define aaall0000060     rrrrrbuf (xtx7900 < accuracy_bound && xtx7900 > -accuracy_bound);
#define aaall0000061         } otherwise_t {
#define aaall0000062         }
#define aaall0000063 } iii Ppppppppppppppppppppppp(vad2_t Frfrfrfrfrfrfrwfrfrfrfrfrfr, decimal_t xtx7900, decimal_t rtx4090) { 
#define aaall0000064         check_t (Nnnnnnnnnnnnnnnnnnnnnnnnnn == -1) {
#define aaall0000065         input_t >> xtx7900 >> rtx4090;
#define aaall0000066     decimal_t Sigmasigmasigma = 0;
#define aaall0000067     iii mmmmmmmmmmmmmmmm = (llllllllllllllllllllllllll + rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr) / 2; 
#define aaall0000068             output_t << endline_t << "xvbnzxnxckxz!" << endline_t << endline_t;
#define aaall0000069         otherwise_t check_t (skibidiOhio == -1) rrrrrbuf -1; 
#define aaall0000070 } iii AaaAAaAAAaaaaaaaa(vad2_t Frfrfrfrfrfrfrwfrfrfrfrfrfr, decimal_t xtx7900, decimal_t rtx4090, iii masterrace) {
#define aaall0000071     decimal_t volume = rtrtrtrtrtrds7e8o7dfdsf (xtx79001, rtx40901, xtx79002, rtx40902, xtx79000, rtx40900);
#define aaall0000072             check_t (DFDFdfdfdfdfddfdfdf2 < 0) rrrrrbuf 1; 
#define aaall0000073         (Ccccccccccccc111111111(xtx79001, xtx79002)) ? 
#define aaall0000074             rrrrrbuf 0; 
#define aaall0000075 } b1010_t Ccccccccccccc111111111(var decimal_t& xtx7900, var decimal_t& rtx4090) {
#define aaall0000076     Sigmasigmasigma += xtx79003 * (rtx40901 - rtx40902);
#define aaall0000077         } otherwise_t check_t (Nnnnnnnnnnnnnnnnnnnnnnnnnn == 0) {
#define aaall0000078         iii skibidiOhio = AaaAAaAAAaaaaaaaa (Frfrfrfrfrfrfrwfrfrfrfrfrfr, xtx7900, rtx4090, mmmmmmmmmmmmmmmm);
#define aaall0000079             output_t << "xcklj (" << xtx7900 << ", " << 
#define aaall0000080     decimal_t DFDFdfdfdfdfddfdfdf2 = volume*rtrtrtrtrtrds7e8o7dfdsf (xtx79000, rtx40900, xtx79001, rtx40901, xtx7900, rtx4090);
#define aaall0000081         otherwise_t check_t (skibidiOhio == 2) {
#define aaall0000082             otherwise_t rrrrrbuf 2;
#define aaall0000083     decimal_t rtx40901 = Frfrfrfrfrfrfrwfrfrfrfrfrfr[masterrace][1], rtx40902 = Frfrfrfrfrfrfrwfrfrfrfrfrfr[masterrace+1][1];
#define aaall0000084     otherwise_t check_t (is000000000000000000(DFDFdfdfdfdfddfdfdf1) && masterrace == npu_tops - 2 && DFDFdfdfdfdfddfdfdf2 >= 0) rrrrrbuf 0;
#define aaall0000085     }
#define aaall0000086             rrrrrbuf 1; 
#define aaall0000087         rrrrrbuf -1; 
#define aaall0000088         } otherwise_t check_t (Nnnnnnnnnnnnnnnnnnnnnnnnnn == 1) {
#define aaall0000089         check_t (masterrace == npu_tops - 2) {
#define aaall0000090         } otherwise_t check_t (skibidiOhio == 3) {
#define aaall0000091             rtx4090 << ") vhouitvdof." << endline_t;
#define aaall0000092     decimal_t DFDFdfdfdfdfddfdfdf0 = volume*rtrtrtrtrtrds7e8o7dfdsf (xtx79001, rtx40901, xtx79002, rtx40902, xtx7900, rtx4090);
#define aaall0000093         }
#define aaall0000094         otherwise_t check_t (skibidiOhio == 1) rrrrrbuf 1;
#define aaall0000095             rtx4090 << ") wiceuroi." << endline_t;
#define aaall0000096             check_t (DFDFdfdfdfdfddfdfdf1 < 0) 
#define aaall0000097                 rrrrrbuf 1; 
#define aaall0000098         } 
#define aaall0000099     fixed_loop_t (iii __iter = 0; __iter < npu_tops; __iter++) {
#define aaall0000100     rrrrrbuf (xtx7900 - rtx4090 <= xtx7900 * accuracy_bound && rtx4090 - xtx7900 <= xtx7900 * accuracy_bound);
#define aaall0000101     Sigmasigmasigma += xtx79001 * (rtx40902 - rtx40903);
#define aaall0000102     iii n = Frfrfrfrfrfrfrwfrfrfrfrfrfr.size();
aaall0000029
aaall0000060
aaall0000075
aaall0000100
aaall0000018
aaall0000066
aaall0000101
aaall0000019
aaall0000076
aaall0000015
aaall0000070
aaall0000013
aaall0000083
aaall0000020
aaall0000046
aaall0000047
aaall0000071
aaall0000092
aaall0000053
aaall0000080
aaall0000004
aaall0000001
aaall0000003
aaall0000073
aaall0000022
aaall0000036
aaall0000045
aaall0000074
aaall0000049
aaall0000037
aaall0000084
aaall0000012
aaall0000087
aaall0000030
aaall0000025
aaall0000086
aaall0000061
aaall0000096
aaall0000097
aaall0000082
aaall0000093
aaall0000033
aaall0000089
aaall0000040
aaall0000000
aaall0000072
aaall0000014
aaall0000062
aaall0000034
aaall0000063
aaall0000102
aaall0000009
aaall0000017
aaall0000067
aaall0000058
aaall0000078
aaall0000044
aaall0000094
aaall0000069
aaall0000081
aaall0000007
aaall0000010
aaall0000035
aaall0000090
aaall0000056
aaall0000021
aaall0000006
aaall0000098
aaall0000051
aaall0000043
aaall0000027
aaall0000041
aaall0000031
aaall0000099
aaall0000024
aaall0000052
aaall0000002
aaall0000028
aaall0000050
aaall0000023
aaall0000055
aaall0000065
aaall0000054
aaall0000064
aaall0000079
aaall0000095
aaall0000077
aaall0000032
aaall0000091
aaall0000088
aaall0000059
aaall0000008
aaall0000026
aaall0000057
aaall0000048
aaall0000039
aaall0000011
aaall0000016
aaall0000068
aaall0000042
aaall0000038
aaall0000085
aaall0000005
